from django import forms
from .models import Movie

class MovieForm(forms.ModelForm):
    title = forms.CharField(max_length=20)
    audience = forms.IntegerField()
    description = forms.CharField(
        widget=forms.Textarea()
    )
    
    genre = forms.CharField(
        max_length=30,
        widget=forms.Select(
            choices=[
                ('코미디', '코미디'),
                ('공포', '공포'),
                ('로맨스', '로맨스'),
                ('액션', '액션'),
                ('SF', 'SF'),
                ('다큐멘터리', '다큐멘터리'),
            ]
        )
    )
    
    score = forms.FloatField(
        max_value=5,
        min_value=0,
        widget=forms.NumberInput(
            attrs={
                'step' : 0.5,
            }
        )
    )

    release_date = forms.DateField(
        widget=forms.DateInput(
            attrs={
                'type' : 'date',
            }
        )
    )

    # add score and release_date 
    class Meta:
        model = Movie
        fields = '__all__'