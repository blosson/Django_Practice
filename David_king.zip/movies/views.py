from .models import Movie
from .forms import MovieForm
from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods, require_POST, require_safe
from django.contrib.auth.decorators import login_required

# Create your views here.
@require_safe
def index(request):
    movies_comedy = Movie.objects.filter(genre='코미디')
    movies_horror = Movie.objects.filter(genre='공포')
    movies_romance = Movie.objects.filter(genre='로맨스')
    movies_action = Movie.objects.filter(genre='액션')
    movies_sf = Movie.objects.filter(genre='SF')
    movies_docu = Movie.objects.filter(genre='다큐멘터리')
    context = {
        'movies_comedy' : movies_comedy,
        'movies_horror' : movies_horror,
        'movies_romance' : movies_romance,
        'movies_action' : movies_action,
        'movies_sf' : movies_sf,
        'movies_docu' : movies_docu,
    }
    return render(request, 'movies/index.html', context)


@require_http_methods(['GET', 'POST'])
def create(request):
    if request.method == 'POST':
        form = MovieForm(request.POST)
        if form.is_valid():
            movie = form.save()
            return redirect('movies:detail', movie.pk)
    else:
        form = MovieForm()
    context = {
        'form' : form,
    }
    return render(request, 'movies/create.html', context)


@require_safe
def detail(request, pk):
    movie = Movie.objects.get(pk=pk)
    context = {
        'movie' : movie,
    }
    return render(request, 'movies/detail.html', context)


@require_http_methods(['GET', 'POST'])
def update(request, pk):
    movie = Movie.objects.get(pk=pk)
    if request.method == 'POST':
        form = MovieForm(request.POST, instance=movie)
        if form.is_valid():
            movie = form.save()
            return redirect('movies:detail', movie.pk)
    else:
        form = MovieForm(instance=movie)
        poster = Movie.objects.get(pk=pk).poster_url
    context = {
        'form' : form,
        'poster' : poster,
        'pk' : pk,
    }
    
    return render(request, 'movies/update.html', context)

@require_POST
def delete(request, pk):
    movie = Movie.objects.get(pk=pk)
    movie.delete()
    return redirect('movies:index')